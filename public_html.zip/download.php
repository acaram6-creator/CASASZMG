<?php
declare(strict_types=1);
require __DIR__.'/db.php';
if(session_status()!==PHP_SESSION_ACTIVE)session_start();
if(!logged_in()){http_response_code(403);exit('Debes iniciar sesión para acceder a este archivo.');}
$me=current_admin();if(!$me){http_response_code(403);exit('Cuenta no autorizada.');}
$type=$_GET['type']??'';$id=(int)($_GET['id']??0);$path='';$name='documento';
if($type==='document'){$st=db()->prepare('SELECT title,file_path FROM site_documents WHERE id=?');$st->execute([$id]);$r=$st->fetch();if($r){$path=$r['file_path'];$name=$r['title'];}}
elseif($type==='contract'){$st=db()->prepare("SELECT ct.* FROM contract_templates ct LEFT JOIN contract_template_users cu ON cu.template_id=ct.id WHERE ct.id=? AND ct.is_active=1 AND (ct.access_mode='all' OR cu.user_id=? OR ?='Administrador') GROUP BY ct.id");$st->execute([$id,$me['id'],$me['role']]);$r=$st->fetch();if($r){$path=$r['file_path'];$name=$r['title'];}}
if(!$path||!is_file(__DIR__.'/'.$path)){http_response_code(404);exit('Archivo no encontrado o sin permisos.');}
$full=realpath(__DIR__.'/'.$path);$base=realpath(__DIR__.'/uploads');if(!$full||!$base||strpos($full,$base.DIRECTORY_SEPARATOR)!==0){http_response_code(403);exit('Ruta no permitida.');}
$ext=strtolower(pathinfo($full,PATHINFO_EXTENSION));$mime=(new finfo(FILEINFO_MIME_TYPE))->file($full)?:'application/octet-stream';$safe=preg_replace('/[^A-Za-z0-9._-]+/','_', $name).'.'.$ext;
header('Content-Type: '.$mime);header('Content-Length: '.filesize($full));header('Content-Disposition: inline; filename="'.$safe.'"');header('X-Content-Type-Options: nosniff');readfile($full);exit;
