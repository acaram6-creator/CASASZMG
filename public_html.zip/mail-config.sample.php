<?php
// Copia este archivo como mail-config.php en public_html.
// Escribe la contraseña SMTP directamente en cPanel/administrador de archivos.
return [
  'smtp_host' => 'mail.alianzainmob.com',
  'smtp_port' => 465,
  'smtp_encryption' => 'ssl',
  'smtp_user' => 'contacto@alianzainmob.com',
  'smtp_pass' => 'COLOCA_AQUI_LA_CONTRASENA_DEL_CORREO',
  'smtp_from' => 'contacto@alianzainmob.com',
  'mail_bcc' => 'depazsmg1@gmail.com',
];
