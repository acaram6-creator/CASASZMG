<?php
require __DIR__.'/db.php';
if(session_status()!==PHP_SESSION_ACTIVE) session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
function ai_json(array $data,int $status=200):void{http_response_code($status);echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
if($_SERVER['REQUEST_METHOD']!=='POST') ai_json(['reply'=>'Método no permitido.'],405);
$body=json_decode(file_get_contents('php://input'),true)?:[];
$message=trim((string)($body['message']??''));
if($message===''||mb_strlen($message)>1200) ai_json(['reply'=>'Escribe una búsqueda de hasta 1,200 caracteres.'],400);
if(!isset($_SESSION['ai_history'])||!is_array($_SESSION['ai_history'])) $_SESSION['ai_history']=[];
$history=&$_SESSION['ai_history'];
$history[]= ['role'=>'user','content'=>$message];
if(count($history)>20) $history=array_slice($history,-20);
$rows=db()->query("SELECT p.id,p.title,p.operation,p.type,p.price,p.location,p.zone,p.bedrooms,p.bathrooms,p.area,p.construction_m2,p.parking,p.maintenance_fee,p.no_maintenance,p.description,COALESCE(NULLIF(p.image,''),(SELECT pi.image_path FROM property_images pi WHERE pi.property_id=p.id ORDER BY pi.sort_order,pi.id LIMIT 1)) AS image FROM properties p LEFT JOIN admins a ON a.id=p.owner_id WHERE p.status='Publicada' AND (p.owner_id IS NULL OR a.is_active=1) ORDER BY p.created_at DESC LIMIT 250")->fetchAll();
$catalog=[];foreach($rows as $r){$catalog[]=['id'=>(int)$r['id'],'title'=>$r['title'],'operation'=>$r['operation'],'type'=>$r['type'],'price'=>(float)$r['price'],'location'=>$r['location'],'zone'=>$r['zone'],'bedrooms'=>$r['bedrooms'],'bathrooms'=>$r['bathrooms'],'area'=>$r['area'],'construction_m2'=>$r['construction_m2'],'parking'=>$r['parking'],'maintenance_fee'=>$r['maintenance_fee'],'no_maintenance'=>(bool)$r['no_maintenance'],'description'=>mb_substr((string)$r['description'],0,500),'image'=>$r['image']];}
$system="Eres ALIANZA INMOBILIARIA AI, asistente inmobiliario en español. Ayudas a encontrar inmuebles SOLO del inventario JSON que recibes. Nunca inventes inmuebles, precios, ubicaciones ni disponibilidad. Conserva todo el contexto de esta conversación y no preguntes de nuevo datos que el usuario ya proporcionó. Si falta un dato decisivo, pregunta solo una cosa (por ejemplo, compra o renta); si ya hay datos suficientes, recomienda coincidencias. Si no hay coincidencias exactas, explica y ofrece alternativas reales. Responde con tono cálido y breve. Devuelve EXCLUSIVAMENTE JSON válido con las claves reply (texto al usuario) y property_ids (array de IDs existentes, máximo 6). No incluyas IDs si no hay coincidencias útiles. Inventario actual: ".json_encode($catalog,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
$messages=[['role'=>'system','content'=>$system]];foreach($history as $h)$messages[]=$h;
$apiKey=getenv('OPENAI_API_KEY')?:($config['openai_api_key']??'');
if(!$apiKey){$history[]= ['role'=>'assistant','content'=>'El asistente está preparado, pero falta configurar la API de inteligencia artificial.'];ai_json(['reply'=>'El buscador inteligente ya está integrado con el inventario, pero falta conectar la clave de API para activar las respuestas de IA. Configura OPENAI_API_KEY en el servidor y vuelve a intentarlo.','properties'=>[],'configured'=>false]);}
if(!function_exists('curl_init')) ai_json(['reply'=>'El servidor necesita habilitar cURL para conectar el asistente.'],503);
$payload=['model'=>$config['openai_model']??'gpt-4o-mini','messages'=>$messages,'temperature'=>0.25,'response_format'=>['type'=>'json_object']];
$ch=curl_init('https://api.openai.com/v1/chat/completions');curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_RETURNTRANSFER=>true,CURLOPT_HTTPHEADER=>['Content-Type: application/json','Authorization: Bearer '.$apiKey],CURLOPT_POSTFIELDS=>json_encode($payload),CURLOPT_CONNECTTIMEOUT=>10,CURLOPT_TIMEOUT=>35]);$raw=curl_exec($ch);$err=curl_error($ch);$status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
if($raw===false||$status<200||$status>=300){error_log('Alianza AI API error: '.$status.' '.$err.' '.substr((string)$raw,0,500));ai_json(['reply'=>'En este momento no pude conectar con el asistente. Intenta nuevamente en unos minutos.','properties'=>[]],503);}
$api=json_decode($raw,true);$content=$api['choices'][0]['message']['content']??'';$answer=json_decode($content,true);
if(!is_array($answer)) ai_json(['reply'=>'No pude interpretar la respuesta. ¿Puedes reformular tu búsqueda?','properties'=>[]]);
$reply=trim((string)($answer['reply']??'¿Qué tipo de propiedad estás buscando?'));$ids=array_values(array_unique(array_filter(array_map('intval',(array)($answer['property_ids']??[])),fn($id)=>$id>0)));$byId=[];foreach($catalog as $item)$byId[$item['id']]=$item;$properties=[];foreach(array_slice($ids,0,6) as $id){if(isset($byId[$id])){$r=$byId[$id];$properties[]=['id'=>$r['id'],'title'=>$r['title'],'price'=>'$'.number_format($r['price'],0,'.',',').' MXN'.($r['operation']==='Renta'?' / mes':''),'location'=>$r['location'],'image'=>$r['image']];}}
$history[]= ['role'=>'assistant','content'=>$content];if(count($history)>20)$history=array_slice($history,-20);
ai_json(['reply'=>$reply,'properties'=>$properties,'configured'=>true]);
