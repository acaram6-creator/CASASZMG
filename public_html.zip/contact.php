<?php
require __DIR__.'/db.php';
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);exit('Método no permitido');}
session_start();verify_csrf();
$name=trim($_POST['name']??'');$email=trim($_POST['email']??'');$phone=trim($_POST['phone']??'');$property=trim($_POST['property']??'');$message=trim($_POST['message']??'');
if(!$name||!filter_var($email,FILTER_VALIDATE_EMAIL)||!$message){http_response_code(422);exit('Completa nombre, correo y mensaje válidos.');}
$config=require __DIR__.'/config.php';
ensure_schema();
$propertyId=null;$ownerId=null;$requestedPropertyId=(int)($_POST['property_id']??0);
if($requestedPropertyId>0){$st=db()->prepare('SELECT id,owner_id,title FROM properties WHERE id=? AND status=\'Publicada\'');$st->execute([$requestedPropertyId]);$pr=$st->fetch();}elseif($property!==''){$st=db()->prepare('SELECT id,owner_id,title FROM properties WHERE title=? ORDER BY id DESC LIMIT 1');$st->execute([$property]);$pr=$st->fetch();}else{$pr=false;}
if($pr){$propertyId=(int)$pr['id'];$ownerId=$pr['owner_id']!==null?(int)$pr['owner_id']:null;$property=$pr['title'];}
$st=db()->prepare('INSERT INTO contact_messages(property_id,owner_id,name,email,phone,property_title,message) VALUES(?,?,?,?,?,?,?)');
$st->execute([$propertyId,$ownerId,$name,$email,$phone,$property,$message]);
// CRM: registrar la solicitud como una nueva oportunidad pendiente de asignación manual.
$phoneNorm=preg_replace('/\D+/','',$phone);$find=db()->prepare("SELECT id FROM crm_clients WHERE (?<>'' AND email=?) OR (?<>'' AND phone_norm=?) ORDER BY id LIMIT 1");$find->execute([strtolower($email),strtolower($email),$phoneNorm,$phoneNorm]);$clientId=(int)($find->fetchColumn()?:0);$duplicateFound=$clientId>0;if($clientId){db()->prepare("UPDATE crm_clients SET name=IF(name='',?,name),email=IF(email='',?,email),phone=IF(phone='',?,phone),phone_norm=IF(phone_norm='',?,phone_norm) WHERE id=?")->execute([$name,strtolower($email),$phone,$phoneNorm,$clientId]);}else{db()->prepare('INSERT INTO crm_clients(name,email,phone,phone_norm) VALUES(?,?,?,?)')->execute([$name,strtolower($email),$phone,$phoneNorm]);$clientId=(int)db()->lastInsertId();}$leadText="Solicitud web: ".$message;db()->prepare("INSERT INTO crm_leads(client_id,property_id,client_type,operation,source,status,priority,message,created_by,assigned_to) VALUES(?,?,?,?,?,'Nuevo','Media',?,NULL,NULL)")->execute([$clientId,$propertyId,$propertyId?'Comprador':'Comprador',$propertyId?'Compra':'Compra','Formulario web',$leadText]);$leadId=(int)db()->lastInsertId();$admins=db()->query("SELECT id,email FROM admins WHERE role='Administrador' AND is_active=1")->fetchAll();foreach($admins as $ad){db()->prepare('INSERT INTO crm_notifications(user_id,title,body) VALUES(?,?,?)')->execute([$ad['id'],'Nuevo prospecto web','Se recibió una solicitud web. Prospecto CRM #'.$leadId.($duplicateFound?' Coincide con un cliente existente; se vinculó al mismo registro.':'')]);if(filter_var($ad['email']??'',FILTER_VALIDATE_EMAIL)){$headers="From: ALIANZA INMOBILIARIA <".$config['contact_email'].">\r\nContent-Type: text/plain; charset=UTF-8\r\n";@mail($ad['email'],'=?UTF-8?B?'.base64_encode('Nuevo prospecto web').'?=',"Se recibió una solicitud de $name. Folio CRM #$leadId. Ingresa al panel para asignarla.",$headers);}}
$subject='SOLICITUD INFO PAGINA';
$body="Nueva solicitud desde alianzainmob.com\n\nNombre: $name\nCorreo: $email\nTeléfono: $phone\nPropiedad: $property\n\nMensaje:\n$message\n";
$headers="From: ALIANZA INMOBILIARIA <".$config['contact_email'].">\r\nReply-To: ".$email."\r\nContent-Type: text/plain; charset=UTF-8\r\n";
$sent=mail($config['contact_email'],'=?UTF-8?B?'.base64_encode($subject).'?=',$body,$headers);
if(!$sent){http_response_code(500);exit('No se pudo enviar el correo. Verifica la configuración de correo saliente en cPanel.');}
header('Location: index.php?sent=1#contacto');exit;
