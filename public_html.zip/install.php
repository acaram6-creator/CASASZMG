<?php
declare(strict_types=1);
session_start();
$done = file_exists(__DIR__.'/config.php');
$error=''; $success='';
if ($_SERVER['REQUEST_METHOD']==='POST' && !$done) {
  $host=trim($_POST['db_host']??'localhost');
  $name=trim($_POST['db_name']??''); $user=trim($_POST['db_user']??'');
  $pass=(string)($_POST['db_pass']??''); $admin=trim($_POST['admin_user']??'');
  $adminpass=(string)($_POST['admin_pass']??'');
  $email=trim($_POST['contact_email']??'contacto@alianzainmob.com');
  if(!$name||!$user||strlen($adminpass)<12||!filter_var($email,FILTER_VALIDATE_EMAIL)) {
    $error='Completa los datos. La contraseña del administrador debe tener al menos 12 caracteres.';
  } else {
    try {
      $pdo=new PDO("mysql:host=$host;dbname=$name;charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
      $sql=file_get_contents(__DIR__.'/schema.sql');
      foreach(array_filter(array_map('trim',explode(';',$sql))) as $statement){$pdo->exec($statement);}
      $st=$pdo->prepare('INSERT INTO admins(username,password_hash) VALUES(?,?)');
      $st->execute([$admin,password_hash($adminpass,PASSWORD_DEFAULT)]);
      $config="<?php\nreturn ".var_export([
        'db_host'=>$host,'db_name'=>$name,'db_user'=>$user,'db_pass'=>$pass,
        'site_url'=>'https://www.alianzainmob.com','contact_email'=>$email,'whatsapp'=>'523324248110'
      ],true).";\n";
      if(file_put_contents(__DIR__.'/config.php',$config,LOCK_EX)===false) throw new RuntimeException('No se pudo crear config.php. Revisa permisos de la carpeta.');
      $success='Instalación completada. Por seguridad, elimina install.php ahora y entra a admin.php.';
      $done=true;
    } catch(Throwable $e){$error='No se pudo completar: '.$e->getMessage();}
  }
}
?><!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Instalación | ALIANZA INMOBILIARIA</title><link rel="icon" href="assets/favicon.ico"><link rel="stylesheet" href="style.css"></head><body class="install"><main class="install-card"><img src="assets/logo-alianza.png" alt="ALIANZA INMOBILIARIA"><p class="eyebrow">CONFIGURACIÓN INICIAL</p><h1>Instalar ALIANZA INMOBILIARIA</h1>
<?php if($done && !$success):?><p class="notice">Ya existe config.php. Si ya instalaste el sistema, elimina install.php.</p><a class="btn" href="admin.php">Ir al administrador</a>
<?php else: if($error):?><p class="error"><?=htmlspecialchars($error)?></p><?php endif; if($success):?><p class="success"><?=htmlspecialchars($success)?></p><a class="btn" href="admin.php">Abrir administrador</a><?php else:?>
<p>Primero crea una base de datos y un usuario MySQL en cPanel → Bases de datos MySQL. Introduce aquí los datos que te proporciona cPanel.</p>
<form method="post">
<h3>Base de datos MySQL</h3>
<label>Servidor<input name="db_host" value="localhost" required></label><label>Nombre de la base de datos<input name="db_name" required placeholder="usuario_alianza"></label><label>Usuario MySQL<input name="db_user" required placeholder="usuario_dbuser"></label><label>Contraseña MySQL<input name="db_pass" type="password" required></label>
<h3>Cuenta administradora</h3><label>Usuario administrador<input name="admin_user" required value="admin"></label><label>Contraseña (mínimo 12 caracteres)<input name="admin_pass" type="password" minlength="12" required></label><label>Correo de contacto<input name="contact_email" type="email" value="contacto@alianzainmob.com" required></label><button class="btn" type="submit">Instalar sistema</button></form><?php endif; endif;?></main></body></html>
