<?php
// Copia este archivo a config.php y completa los datos de MySQL de cPanel.
return [
  'db_host' => 'localhost',
  'db_name' => 'USUARIOCPANEL_alianza',
  'db_user' => 'USUARIOCPANEL_dbuser',
  'db_pass' => 'CAMBIA_ESTA_CLAVE',
  'site_url' => 'https://www.alianzainmob.com',
  'contact_email' => 'contacto@alianzainmob.com',
  'whatsapp' => '523324248110',
  // Configuración opcional del asistente IA. También puedes usar la variable de entorno OPENAI_API_KEY.
  'openai_api_key' => '',
  'openai_model' => 'gpt-4o-mini',
];
