<?php
return array (
  'db_host' => 'localhost',
  'db_name' => 'alianzai_ali',
  'db_user' => 'alianzai_iali',
  'db_pass' => 'NalaKongo505',
  'site_url' => 'https://www.alianzainmob.com',
  'contact_email' => 'contacto@alianzainmob.com',
  'whatsapp' => '523324248110',
);
